var mes = prompt("Mes de Nacimiento")
var dia = prompt("Día de Nacimiento")

if(mes == 1){
  if(dia <= 20){
    alert("Es Aries")
  } else{
    alert("Es Acuario")
  }
}
if(mes == 2){
  if(dia <= 19){
    alert("Es Acuario")
  } else{
    alert("Es Piscis")
  }
}
if(mes == 3){
  if(dia <= 20){
    alert("Es Piscis")
  } else{
    alert("Es Aries")
  }
}
if(mes == 4){
  if(dia <= 20){
    alert("Es Aries")
  } else{
    alert("Es Tauro")
  }
}
if(mes == 5){
  if(dia <= 20){
    alert("Es Tauro")
  } else{
    alert("Es Géminis")
  }
}
if(mes == 6){
  if(dia <= 20){
    alert("Es Géminis")
  } else{
    alert("Es Cáncer")
  }
}
if(mes == 7){
  if(dia <= 21){
    alert("Es Cáncer")
  } else{
    alert("Es Leo")
  }
}
if(mes == 8){
  if(dia <= 22){
    alert("Es Leo")
  } else{
    alert("Es Virgo")
  }
}
if(mes == 9){
  if(dia <= 22){
    alert("Es Virgo")
  } else{
    alert("Es Libra")
  }
}
if(mes == 10){
  if(dia <= 23){
    alert("Es Libra")
  } else{
    alert("Es Escorpio")
  }
}
if(mes == 11){
  if(dia <= 22){
    alert("Es Escorpio")
  } else{
    alert("Es Sagitario")
  }
}
if(mes == 12){
  if(dia <= 21){
    alert("Es Sagitario")
  } else{
    alert("Es Capricornio")
  }
}